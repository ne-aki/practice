package com.home.back_diary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackDiaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
