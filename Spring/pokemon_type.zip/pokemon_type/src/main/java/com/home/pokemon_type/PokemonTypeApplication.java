package com.home.pokemon_type;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokemonTypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PokemonTypeApplication.class, args);
	}

}
